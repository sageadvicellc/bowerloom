# Sync modes

See `./local-collections.md` for the local mode.
