# Joins

Synthetic reference text.
