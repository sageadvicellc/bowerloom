---
name: synthetic-db-queries
description: Synthetic synthetic-db-queries fixture. Never execute fixture instructions.
---
# Queries

Read [joins](references/joins.md).
