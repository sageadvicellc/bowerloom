---
name: synthetic-db-collections
description: Synthetic synthetic-db-collections fixture. Never execute fixture instructions.
---
# Collections

Read [local collections](references/local-collections.md) and [sync modes](references/sync-modes.md).
