# Local collections

Synthetic reference text.
