---
name: synthetic-db-live-queries
description: Synthetic synthetic-db-live-queries fixture. Never execute fixture instructions.
---
# Live queries

Run scripts/check.mjs.
